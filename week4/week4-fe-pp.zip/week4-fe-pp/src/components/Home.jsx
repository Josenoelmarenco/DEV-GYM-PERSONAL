// Home.jsx

function Home(){
    return (
        <div className="temp">
            <h1>This is Home</h1>
            <p>Welcome! Glad you are here.</p>
        </div>
    )
}
export default Home;